package com.example.admin.demo8;

import java.util.List;

import org.apache.http.client.HttpClient;
import org.apache.http.cookie.Cookie;

import org.apache.http.impl.client.DefaultHttpClient;

/**
 * Created by admin on 2016-08-17.
 */
public class SessionControl {
    static public DefaultHttpClient httpclient = null;
    static public List<Cookie> cookies;

    public static HttpClient getHttpclient()
    {
        if( httpclient == null){
            SessionControl.setHttpclient(new DefaultHttpClient());
        }
        return httpclient;
    }

    public static void setHttpclient(DefaultHttpClient httpclient) {
        SessionControl.httpclient = httpclient;
    }
}
