package com.example.admin.demo8;

/**
 * Created by admin on 2016-08-05.
 */

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

/**스플래시 (로딩화면) 액티비티*/
public class Splash  extends Activity {

    //SharedPreferences setting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            //1초간 대기하고
            Thread.sleep(1000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        //로그인 액티비티로 넘어간다
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }
}
