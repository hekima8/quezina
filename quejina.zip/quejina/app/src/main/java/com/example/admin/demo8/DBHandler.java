package com.example.admin.demo8;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

/**
 * Created by admin on 2016-09-10.
 */
public class DBHandler {
    private DBHelper helper;
    private SQLiteDatabase db;

    private DBHandler(Context context) {
        this.helper = new DBHelper(context);
        this.db = helper.getWritableDatabase();
    }

    public static DBHandler open(Context context) throws SQLException{
        DBHandler handler = new DBHandler(context);
        return handler;
    }
    //닫기
    public void close() {helper.close();}

    //저장
    public long insert(String c_id, String coupon_name) {
        //db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("c_id", c_id);
        values.put("coupon_name", coupon_name);
        return db.insert("coupontb", null, values);
    }
    public Cursor select(String id) throws SQLException {
        db = helper.getReadableDatabase();
        Cursor cursor = db.query(true, "coupontb", new String[]{"c_id", "coupon_name"}, "c_id"+"="+"\""+id +"\"", null, null, null, null, null);
        if(cursor != null) {
            cursor.moveToFirst();
        }
        return cursor;
    }
}
