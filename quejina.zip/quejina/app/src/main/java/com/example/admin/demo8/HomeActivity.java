package com.example.admin.demo8;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.media.Image;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.RemoteException;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.perples.recosdk.RECOBeacon;
import com.perples.recosdk.RECOBeaconManager;
import com.perples.recosdk.RECOBeaconRegion;
import com.perples.recosdk.RECOErrorCode;
import com.perples.recosdk.RECORangingListener;
import com.perples.recosdk.RECOServiceConnectListener;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Locale;

/**
 * Created by admin on 2016-08-09.
 */
public class HomeActivity extends AppCompatActivity implements RECOServiceConnectListener, RECORangingListener, View.OnClickListener {

    public int temp=0, old=0, oold=0; //3번 똑같은 게 들어왔는지 알아보도록
    public int[] count = new int[10]; //각 비콘마다 최단거리에 있는 비콘일 때 카운트 증가
    public String[] change_count = new String[10]; //카운트를 스트링으로 바꿔서 디비에 저장

    // 장기테이블 데이터를 받아올 PHP 주소
   // String url = "http://10.200.14.11:80/changsun/couponcheck.php";
    Typeface typeface;

    //장기테이블 배열
    String longterm[];

    // 데이터를 보기위한 TextView
    TextView tv;
    // PHP를 읽어올때 사용할 변수
    public GettingPHP gPHP;

    //마지막으로 뒤로가기 버튼이 터치된 시간
    private long lastTimeBackPressed;

    public static final String RECO_UUID = "24DDF411-8CF1-440C-87CD-E368DAF9C93E";

    public static final boolean SCAN_RECO_ONLY = true;
    public static final boolean ENABLE_BACKGROUND_RANGING_TIMEOUT = true;

    public static final boolean DISCONTINUOUS_SCAN = false;

    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_LOCATION = 10;//시간인가?

    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;

    protected RECOBeaconManager mRecoManager;
    protected ArrayList<RECOBeaconRegion> mRegions;

    private RecoRangingListAdapter mRangingListAdapter;
    private ListView mRegionListView;

    private int flag=0; //쿠폰을 한번만 띄우기 위한 플래그

    private View mLayout;

    //ProgressDialog dialog = null;
    HttpPost httpPost;
    HttpResponse response;
    HttpClient httpclient;
    HttpClientt hc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        //setTitle("쾌지나창창 마트");

        mLayout = findViewById(R.id.mainLayout);

        mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = mBluetoothManager.getAdapter();

        mRecoManager = RECOBeaconManager.getInstance(getApplicationContext(), HomeActivity.SCAN_RECO_ONLY, HomeActivity.ENABLE_BACKGROUND_RANGING_TIMEOUT);
        mRegions = this.generateBeaconRegion();
        mRecoManager.setRangingListener(this);

        typeface = Typeface.createFromAsset(getAssets(), "210L.ttf"); //글꼴설정

        Button logoutBtn = (Button) findViewById(R.id.logout_button);
        logoutBtn.setOnClickListener(this);
        Button couponBtn = (Button) findViewById(R.id.coupon_button);
        couponBtn.setOnClickListener(this);

        //logoutBtn.setTypeface(typeface);
        //couponBtn.setTypeface(typeface);
        Intent intent = getIntent();
        String id = intent.getStringExtra("입력한 id");

        try{
            httpclient = SessionControl.getHttpclient();            hc = new HttpClientt();

            String data  = URLEncoder.encode("id", "UTF-8") + "=" + URLEncoder.encode(id, "UTF-8");

            URL url = new URL(hc.addr+"/changsun/turnoff.php");
            URLConnection conn = url.openConnection();

            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

            wr.write( data );
            wr.flush();

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            StringBuilder sb = new StringBuilder();
            String line = null;

            // Read Server Response
            while((line = reader.readLine()) != null)
            {
                sb.append(line);
                break;
            }
        }catch (Exception e){
            System.out.println("Exception: "+e.getMessage());
        }


        hc = new HttpClientt();

        gPHP = new GettingPHP();
        tv = (TextView)findViewById(R.id.aaa);
        //gPHP.execute(url);
        gPHP.execute(hc.addr+":80/changsun/couponcheck.php");

        //장기테이블 초기화
        longterm = new String[11];
        for(int i=0;i<longterm.length;i++){
            longterm[i]="0";
        }

        //각 비콘마다 고객과의 거리가 최단거리일 때 카운트
        for(int i=0; i<count.length;i++)
            count[i] = 0; //처음엔 다 영으로 초기화

        if(mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
            Intent enableBTIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBTIntent, REQUEST_ENABLE_BT);
        }
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if(ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                Log.i("MainActivity", "The location permission (ACCESS_COARSE_LOCATION or ACCESS_FINE_LOCATION) is not granted.");
                this.requestLocationPermission();
            } else {
                Log.i("MainActivity", "The location permission (ACCESS_COARSE_LOCATION or ACCESS_FINE_LOCATION) is already granted.");
            }
        }
        mRecoManager.bind(this);
    }

    /** 장기테이블 가져와서 카운트수 가장 큰 구역에 대한 쿠폰을 띄우기 위한 전 작업 - php에서 값 가져오기!!!!!! */
    class GettingPHP extends AsyncTask<String, Integer, String> {
        Intent intent = getIntent();
        String id = intent.getStringExtra("입력한 id");

        @Override
        protected String doInBackground(String... params) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                URL phpUrl = new URL(params[0]);
                HttpURLConnection conn = (HttpURLConnection)phpUrl.openConnection();

                if ( conn != null ) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);

                    if ( conn.getResponseCode() == HttpURLConnection.HTTP_OK ) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        while ( true ) {
                            String line = br.readLine();
                            if ( line == null )
                                break;
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch ( Exception e ) {
                e.printStackTrace();
            }
            return jsonHtml.toString();
        }

        protected void onPostExecute(String str) {
            try {
                // PHP에서 받아온 JSON 데이터를 JSON오브젝트로 변환
                JSONObject jObject = new JSONObject(str);
                // results라는 key는 JSON배열로 되어있다.
                JSONArray results = jObject.getJSONArray("results");
                String zz = "";
                zz += "Status : " + jObject.get("status");
                zz += "\n";
                zz += "Number of results : " + jObject.get("num_result");
                zz += "\n";
                zz += "Results : \n";

                for ( int i = 0; i < results.length(); ++i ) {
                    JSONObject temp = results.getJSONObject(i);

                    if(id.equals(temp.get("c_id").toString())){
                        zz += "\tc_id : " + temp.get("c_id");
                        zz += "\tone : " + temp.get("one");
                        zz += "\ttwo : " + temp.get("two");
                        zz += "\tthree : " + temp.get("three");
                        zz += "\tfour : " + temp.get("four");
                        zz += "\tfive : " + temp.get("five");
                        zz += "\tsix : " + temp.get("six");
                        zz += "\tseven : " + temp.get("seven");
                        zz += "\teight : " + temp.get("eight");
                        zz += "\tnine : " + temp.get("nine");
                        zz += "\tten : " + temp.get("ten");
                        zz += "\n\t--------------------------------------------\n";
                        longterm[0]=temp.get("c_id").toString();
                        longterm[1]=temp.get("one").toString();
                        longterm[2]=temp.get("two").toString();
                        longterm[3]=temp.get("three").toString();
                        longterm[4]=temp.get("four").toString();
                        longterm[5]=temp.get("five").toString();
                        longterm[6]=temp.get("six").toString();
                        longterm[7]=temp.get("seven").toString();
                        longterm[8]=temp.get("eight").toString();
                        longterm[9]=temp.get("nine").toString();
                        longterm[10]=temp.get("ten").toString();
                    }
                }
                tv.setText(zz);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    /** 카운트가 가장 큰 구역에 대한 쿠폰 번호 리턴하는 함수
     * 만약 2~4구역 중에 하나가 가장 크면 과자 쿠폰 번호 =1
     * 5~7구역 중에 하나가 가장 크면 오뚜기밥 쿠폰 번호 =2
     * 8~10구역 중에 하나가 가장 크면 통조림 쿠폰 번호=3*/
    public String couponCount() {
        String couponNum;
        int maxIndex=findMax();
        Log.v("인덱스 :::::", Integer.toString(maxIndex));

        if(maxIndex==2 || maxIndex==3 || maxIndex==4){
            couponNum="1";
        } else if(maxIndex==5 || maxIndex==6 || maxIndex==7){
            couponNum="2";
        } else {
            couponNum="3";
        }
        Log.v("쿠폰번호 :::::", couponNum);
        return couponNum;
    }

    /** 장기테이블에서 카운트수가 가장 큰 구역 찾는 함수 */
    public int findMax () {
        int maxIndex=1;

        for(int j=1;j<longterm.length;j++){
            if(Integer.parseInt(longterm[maxIndex])<Integer.parseInt(longterm[j])){
                maxIndex=j;
            }
        }
        Log.v("가장 큰 구역 번호 : ", Integer.toString(maxIndex));
        return maxIndex;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.logout_button:
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Looper.prepare();
                        logout();
                        Looper.loop();
                    }
                }).start();
                break;
            case R.id.coupon_button:
                Intent intent = getIntent();
                String id = intent.getStringExtra("입력한 id");

                Intent intent1 = new Intent(this, CouponhamActivity.class);
                intent1.putExtra("홈의 아이디", id);
                startActivity(intent1);
                //startActivity(new Intent(HomeActivity.this, CouponhamActivity.class));
                //finish();
                break;
        }
    }

    public void logout() {
        try{
            httpclient = SessionControl.getHttpclient();

            hc = new HttpClientt();
            httpPost = new HttpPost(hc.addr+"/changsun/logout.php");
            response = httpclient.execute(httpPost);
            startActivity(new Intent(HomeActivity.this, LoginActivity.class));
            finish();
        }catch (Exception e){
            System.out.println("Exception: "+e.getMessage());
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch(requestCode) {
            case REQUEST_LOCATION : {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Snackbar.make(mLayout, R.string.location_permission_granted, Snackbar.LENGTH_LONG).show();
                } else {
                    Snackbar.make(mLayout, R.string.location_permission_not_granted, Snackbar.LENGTH_LONG).show();
                }
            }
            default :
                break;
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_ENABLE_BT && resultCode == Activity.RESULT_CANCELED) {
            //If the request to turn on bluetooth is denied, the app will be finished.
            //사용자가 블루투스 요청을 허용하지 않았을 경우, 어플리케이션은 종료됩니다.
            finish();
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    private void requestLocationPermission() {
        if(!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_COARSE_LOCATION)) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_LOCATION);
            return;
        }

        Snackbar.make(mLayout, R.string.location_permission_rationale, Snackbar.LENGTH_INDEFINITE)
                .setAction(R.string.ok, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ActivityCompat.requestPermissions(HomeActivity.this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_LOCATION);
                    }
                })
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();

        mRangingListAdapter = new RecoRangingListAdapter(this);
        mRegionListView = (ListView)findViewById(R.id.list_item);
        mRegionListView.setAdapter(mRangingListAdapter);
    }

    /**LONGTERM 테이블에 콜럼 추가*/
    @Override
    protected void onStop() {
        super.onStop();

       //count 인트형을 change_count 스트링형으로 바꾸기
        for(int j=0;j<10;j++){
            change_count[j]=String.valueOf(count[j]);
        }

        insertCountToDB(change_count[0], change_count[1], change_count[2], change_count[3],
                change_count[4], change_count[5], change_count[6], change_count[7], change_count[8], change_count[9]);

        System.out.println(change_count[0] +change_count[1]+change_count[2]+change_count[3]+
                change_count[4]+change_count[5]+ change_count[6]+ change_count[7]+ change_count[8]+ change_count[9]);


        Log.i("알림", "onStop 실행");
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.i("알림", "onDestroy 실행");

        this.stop(mRegions);
        this.unbind();
    }

    private void insertCountToDB(String oneC, String twoC, String threeC, String fourC,
                                 String fiveC, String sixC, String sevenC, String eightC, String nineC,
                                 String tenC){
        Intent intent = getIntent();
        final String id = intent.getStringExtra("입력한 id");

        class InsertData2 extends AsyncTask<String, Void, String> {
            ProgressDialog loading;


            /**
             * doInBackground 실행되기 이전에 동작*/
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                //loading = ProgressDialog.show(HomeActivity.this, "Please Wait !!!", null, true, true);
            }


            /**
             * doInBackground 종료되면 동작한다.*/
            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                //loading.dismiss();
                //Toast.makeText(getApplicationContext(),s,Toast.LENGTH_SHORT).show();
            }

            /**
             * 본 작업을 쓰레드로 처리해준다.*/
            @Override
            protected String doInBackground(String... params) {
                try{
                    //String time = (String)params[0];
                    String oneC = (String)params[0];
                    String twoC = (String)params[1];
                    String threeC = (String)params[2];
                    String fourC = (String)params[3];
                    String fiveC = (String)params[4];
                    String sixC = (String)params[5];
                    String sevenC = (String)params[6];
                    String eightC = (String)params[7];
                    String nineC = (String)params[8];
                    String tenC = (String)params[9];



                    hc = new HttpClientt();
                    String link=hc.addr+"/changsun/longterm.php";
                    String data  = URLEncoder.encode("oneC", "UTF-8") + "=" + URLEncoder.encode(oneC, "UTF-8");
                    data += "&" + URLEncoder.encode("twoC", "UTF-8") + "=" + URLEncoder.encode(twoC, "UTF-8");
                    data += "&" + URLEncoder.encode("threeC", "UTF-8") + "=" + URLEncoder.encode(threeC, "UTF-8");
                    data += "&" + URLEncoder.encode("fourC", "UTF-8") + "=" + URLEncoder.encode(fourC, "UTF-8");
                    data += "&" + URLEncoder.encode("fiveC", "UTF-8") + "=" + URLEncoder.encode(fiveC, "UTF-8");
                    data += "&" + URLEncoder.encode("sixC", "UTF-8") + "=" + URLEncoder.encode(sixC, "UTF-8");
                    data += "&" + URLEncoder.encode("sevenC", "UTF-8") + "=" + URLEncoder.encode(sevenC, "UTF-8");
                    data += "&" + URLEncoder.encode("eightC", "UTF-8") + "=" + URLEncoder.encode(eightC, "UTF-8");
                    data += "&" + URLEncoder.encode("nineC", "UTF-8") + "=" + URLEncoder.encode(nineC, "UTF-8");
                    data += "&" + URLEncoder.encode("tenC", "UTF-8") + "=" + URLEncoder.encode(tenC, "UTF-8");
                    data += "&" + URLEncoder.encode("id", "UTF-8") + "=" + URLEncoder.encode(id, "UTF-8");


                    URL url = new URL(link);
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                    wr.write( data );
                    wr.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;

                    // Read Server Response
                    while((line = reader.readLine()) != null)
                    {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();
                }
                catch(Exception e){
                    return new String("Exception: " + e.getMessage());
                }

            }
        }
        InsertData2 task = new InsertData2();
        task.execute(oneC,twoC,threeC,fourC,fiveC,sixC,sevenC,eightC,nineC,tenC, id);
    }


    private void unbind() {
        try {
            mRecoManager.unbind();
        } catch (RemoteException e) {
            Log.i("RECORangingActivity", "Remote Exception");
            e.printStackTrace();
        }
    }

    @Override
    public void onServiceConnect() {
        Log.i("RECORangingActivity", "onServiceConnect()");
        mRecoManager.setDiscontinuousScan(HomeActivity.DISCONTINUOUS_SCAN);
        this.start(mRegions);
        //Write the code when RECOBeaconManager is bound to RECOBeaconService
    }


    /** 최소 거리인 비콘이 1801 (마트 입구)이면 쿠폰 띄우기
     * =====> 각 고객마다 오래, 많이 머무른 구역의 쿠폰 띄우는 걸로 - */
    public void didEnterRegion() {
        if(flag==0){
            if(mRangingListAdapter.CouponPop() == 1801){
                //Log.v("가장 큰 카운트 수 가진 쿠폰 번호ㅗ", num);
                Intent intent = getIntent();
                String id = intent.getStringExtra("입력한 id");

                //팝업 화면으로 고고
                Intent intent1 = new Intent(this, PopupActivity.class);
                intent1.putExtra("쿠폰", couponCount());
                intent1.putExtra("홈에서보낸아이디", id);
                startActivity(intent1);
                //startActivity(new Intent(HomeActivity.this, PopupActivity.class));
                flag=1;
            }
        }
    }

    /**리스트어댑터에서 최단거리 비콘 Major 알아와서 카운트변수 증가*/
    public void increaseCount(int num) {
        temp = num-1801;

        if(temp == old && old == oold){
            count[temp]++;
        }
        oold = old;
        old = temp;
    }

    @Override
    public void didRangeBeaconsInRegion(Collection<RECOBeacon> recoBeacons, RECOBeaconRegion recoRegion) {
        Log.i("RECORangingActivity", "didRangeBeaconsInRegion() region: " + recoRegion.getUniqueIdentifier() + ", number of beacons ranged: " + recoBeacons.size());
        mRangingListAdapter.updateAllBeacons(recoBeacons);
        mRangingListAdapter.notifyDataSetChanged();

        String[] acc;
        int num;
        acc = mRangingListAdapter.getAccur();
        System.out.println(acc[0] +", "+ acc[1] +", "+ acc[2]);
        Date now = new Date();

        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        System.out.println(format.format(now)); // 20090529
        format = new SimpleDateFormat("HH:mm:ss", Locale.KOREA);
        System.out.println(format.format(now)); // Fri May 29 11:06:29

        insertToDatabase(format.format(now), acc[0], acc[1], acc[2], acc[3], acc[4],
                acc[5], acc[6], acc[7], acc[8], acc[9]);

        num = mRangingListAdapter.getMinBeaconNum();
        this.increaseCount(num);
        this.didEnterRegion();
    }

    protected void start(ArrayList<RECOBeaconRegion> regions) {

        for(RECOBeaconRegion region : regions) {
            try {
                mRecoManager.startRangingBeaconsInRegion(region);
            } catch (RemoteException e) {
                Log.i("RECORangingActivity", "Remote Exception");
                e.printStackTrace();
            } catch (NullPointerException e) {
                Log.i("RECORangingActivity", "Null Pointer Exception");
                e.printStackTrace();
            }
        }
    }

    protected void stop(ArrayList<RECOBeaconRegion> regions) {
        for(RECOBeaconRegion region : regions) {
            try {
                mRecoManager.stopRangingBeaconsInRegion(region);
            } catch (RemoteException e) {
                Log.i("RECORangingActivity", "Remote Exception");
                e.printStackTrace();
            } catch (NullPointerException e) {
                Log.i("RECORangingActivity", "Null Pointer Exception");
                e.printStackTrace();
            }
        }
    }
    public void onServiceFail(RECOErrorCode errorCode) {
        //Write the code when the RECOBeaconService is failed.
        //See the RECOErrorCode in the documents.
        return;
    }

    @Override
    public void rangingBeaconsDidFailForRegion(RECOBeaconRegion region, RECOErrorCode errorCode) {
        //Write the code when the RECOBeaconService is failed to range beacons in the region.
        //See the RECOErrorCode in the documents.
        return;
    }


    private ArrayList<RECOBeaconRegion> generateBeaconRegion() {
        ArrayList<RECOBeaconRegion> regions = new ArrayList<RECOBeaconRegion>();

        RECOBeaconRegion recoRegion;
        recoRegion = new RECOBeaconRegion(HomeActivity.RECO_UUID, "RECO Sample Region");
        regions.add(recoRegion);

        return regions;
    }
    private void insertToDatabase(String time, String one, String two, String three, String four,
                                   String five, String six, String seven, String eight, String nine,
                                   String ten){

        class InsertData extends AsyncTask<String, Void, String> {
            ProgressDialog loading;

            /**
             * doInBackground 실행되기 이전에 동작*/
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                //loading = ProgressDialog.show(HomeActivity.this, "Please Wait !!!", null, true, true);
            }


            /**
             * doInBackground 종료되면 동작한다.*/
            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                //loading.dismiss();
                //Toast.makeText(getApplicationContext(),s,Toast.LENGTH_SHORT).show();
            }

            /**
             * 본 작업을 쓰레드로 처리해준다.*/
            @Override
            protected String doInBackground(String... params) {
                try{
                    String time = (String)params[0];
                    String one = (String)params[1];
                    String two = (String)params[2];
                    String three = (String)params[3];
                    String four = (String)params[4];
                    String five = (String)params[5];
                    String six = (String)params[6];
                    String seven = (String)params[7];
                    String eight = (String)params[8];
                    String nine = (String)params[9];
                    String ten = (String)params[10];

                    Intent intent = getIntent();
                    String id = intent.getStringExtra("입력한 id");

                    hc = new HttpClientt();
                    String link=hc.addr+"/changsun/test.php";
                    String data  = URLEncoder.encode("time", "UTF-8") + "=" + URLEncoder.encode(time, "UTF-8");
                    data += "&" + URLEncoder.encode("one", "UTF-8") + "=" + URLEncoder.encode(one, "UTF-8");
                    data += "&" + URLEncoder.encode("two", "UTF-8") + "=" + URLEncoder.encode(two, "UTF-8");
                    data += "&" + URLEncoder.encode("three", "UTF-8") + "=" + URLEncoder.encode(three, "UTF-8");
                    data += "&" + URLEncoder.encode("four", "UTF-8") + "=" + URLEncoder.encode(four, "UTF-8");
                    data += "&" + URLEncoder.encode("five", "UTF-8") + "=" + URLEncoder.encode(five, "UTF-8");
                    data += "&" + URLEncoder.encode("six", "UTF-8") + "=" + URLEncoder.encode(six, "UTF-8");
                    data += "&" + URLEncoder.encode("seven", "UTF-8") + "=" + URLEncoder.encode(seven, "UTF-8");
                    data += "&" + URLEncoder.encode("eight", "UTF-8") + "=" + URLEncoder.encode(eight, "UTF-8");
                    data += "&" + URLEncoder.encode("nine", "UTF-8") + "=" + URLEncoder.encode(nine, "UTF-8");
                    data += "&" + URLEncoder.encode("ten", "UTF-8") + "=" + URLEncoder.encode(ten, "UTF-8");
                    data += "&" + URLEncoder.encode("id", "UTF-8") + "=" + URLEncoder.encode(id, "UTF-8");


                    URL url = new URL(link);
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                    wr.write( data );
                    wr.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;

                    // Read Server Response
                    while((line = reader.readLine()) != null)
                    {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();
                }
                catch(Exception e){
                    return new String("Exception: " + e.getMessage());
                }

            }
        }
        InsertData task = new InsertData();
        task.execute(time,one,two,three,four,five,six,seven,eight,nine,ten);
    }

    @Override
    public void onBackPressed() {
        //1.5초 이내에 뒤로가기 버튼을 또 터치했으면 앱을 종료한다.
        if(System.currentTimeMillis()-lastTimeBackPressed<1500){
            finish();
            return;
        }
        Toast.makeText(this, "'뒤로' 버튼을 한번 더 누르면 종료됩니다.", Toast.LENGTH_SHORT).show();

        //사용자가 뒤로가기 버튼을 터치할 때마다 현재시간을 기록해둔다.
        lastTimeBackPressed = System.currentTimeMillis();
    }

}