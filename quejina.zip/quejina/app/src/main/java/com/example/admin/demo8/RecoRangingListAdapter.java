package com.example.admin.demo8;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.perples.recosdk.RECOBeacon;

import java.util.ArrayList;
import java.util.Collection;

public class RecoRangingListAdapter extends BaseAdapter {
    private ArrayList<RECOBeacon> mRangedBeacons;
    private LayoutInflater mLayoutInflater;

    //public int[] count = new int[10]; //각 비콘마다 최단거리에 있는 비콘일 때 카운트 증가

    public RecoRangingListAdapter(Context context) {
        super();
        mRangedBeacons = new ArrayList<RECOBeacon>();
        mLayoutInflater = LayoutInflater.from(context);
    }

    public void updateBeacon(RECOBeacon beacon) {
        synchronized (mRangedBeacons) {
            if(mRangedBeacons.contains(beacon)) {
                mRangedBeacons.remove(beacon);
            }
            mRangedBeacons.add(beacon);
        }
    }

    public void updateAllBeacons(Collection<RECOBeacon> beacons) {
        synchronized (beacons) {
            mRangedBeacons = new ArrayList<RECOBeacon>(beacons);
        }
    }

    public void clear() {
        mRangedBeacons.clear();
    }

    @Override
    public int getCount() {
        return mRangedBeacons.size();
    }

    @Override
    public Object getItem(int position) {
        return mRangedBeacons.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;

        if(convertView == null) {
            convertView = mLayoutInflater.inflate(R.layout.item_ranging_beacon, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.recoProximityUuid = (TextView)convertView.findViewById(R.id.recoProximityUuid);
            viewHolder.recoMajor = (TextView)convertView.findViewById(R.id.recoMajor);
            viewHolder.recoMinor = (TextView)convertView.findViewById(R.id.recoMinor);
            viewHolder.recoTxPower = (TextView)convertView.findViewById(R.id.recoTxPower);
            viewHolder.recoRssi = (TextView)convertView.findViewById(R.id.recoRssi);
            viewHolder.recoProximity = (TextView)convertView.findViewById(R.id.recoProximity);
            viewHolder.recoAccuracy = (TextView)convertView.findViewById(R.id.recoAccuracy);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder)convertView.getTag();
        }

        RECOBeacon recoBeacon = mRangedBeacons.get(position);

        String proximityUuid = recoBeacon.getProximityUuid();

        viewHolder.recoProximityUuid.setText(String.format("%s-%s-%s-%s-%s", proximityUuid.substring(0, 8), proximityUuid.substring(8, 12), proximityUuid.substring(12, 16), proximityUuid.substring(16, 20), proximityUuid.substring(20) ));
        viewHolder.recoMajor.setText(recoBeacon.getMajor() + "");
        viewHolder.recoMinor.setText(recoBeacon.getMinor() + "");
        viewHolder.recoTxPower.setText(recoBeacon.getTxPower() + "");
        viewHolder.recoRssi.setText(recoBeacon.getRssi() + "");
        viewHolder.recoProximity.setText(recoBeacon.getProximity() + "");
        viewHolder.recoAccuracy.setText(String.format("%.2f", recoBeacon.getAccuracy()));

        return convertView;
    }
/** 최소 거리에 있는 비콘 번호 저장 */
    public double getMinAccur() {
        double min=10.0;

        synchronized (mRangedBeacons) {
            for (int i = 0; i < mRangedBeacons.size(); i++) {
                if (mRangedBeacons.get(i).getAccuracy() < min) {
                    min = mRangedBeacons.get(i).getAccuracy();
                }
            }
        }
        return min;
    }
    /**최소거리에 있는 비콘의 Major 저장*/
    public int getMinBeaconNum() {
        int num=0;
        double min=10.0;
        synchronized (mRangedBeacons) {
            for (int i = 0; i < mRangedBeacons.size(); i++) {
                if (mRangedBeacons.get(i).getAccuracy() < min) {
                    min = mRangedBeacons.get(i).getAccuracy();
                    //num[0] = mRangedBeacons.get(i).getMajor();
                    //num[1] = mRangedBeacons.get(i).getMinor();
                    num=mRangedBeacons.get(i).getMajor();
                }
            }
        }
        return num;
    }

    public String[] getAccur() {
        String[] acc = new String[10];
        synchronized (mRangedBeacons) {
            for (int j=0; j<10; j++)
                acc[j]="none";
            for (int i = 0; i < mRangedBeacons.size(); i++) {
                RECOBeacon recoBeacon = mRangedBeacons.get(i);

                if (1801 == recoBeacon.getMajor())
                    acc[0] = Double.toString(recoBeacon.getAccuracy());
                else if (1802 == recoBeacon.getMajor())
                    acc[1] = Double.toString(recoBeacon.getAccuracy());
                else if (1803 == recoBeacon.getMajor())
                    acc[2] = Double.toString(recoBeacon.getAccuracy());
                else if (1804 == recoBeacon.getMajor())
                    acc[3] = Double.toString(recoBeacon.getAccuracy());
                else if (1805 == recoBeacon.getMajor())
                    acc[4] = Double.toString(recoBeacon.getAccuracy());
                else if (1806 == recoBeacon.getMajor())
                    acc[5] = Double.toString(recoBeacon.getAccuracy());
                else if (1807 == recoBeacon.getMajor())
                    acc[6] = Double.toString(recoBeacon.getAccuracy());
                else if (1808 == recoBeacon.getMajor())
                    acc[7] = Double.toString(recoBeacon.getAccuracy());
                else if (1809 == recoBeacon.getMajor())
                    acc[8] = Double.toString(recoBeacon.getAccuracy());
                else if (1810 == recoBeacon.getMajor())
                    acc[9] = Double.toString(recoBeacon.getAccuracy());
            }
        }
        return acc;
    }

    /**  최소거리인 비콘이 1801이면 ㅇㅇㅇㅇ ->>고쳐야 함!!!!!!!*/
    public int CouponPop() {
        int num=0, k;
        synchronized (mRangedBeacons) {
            for (k = 0; k < mRangedBeacons.size(); k++) {
                if (mRangedBeacons.get(k).getMajor() == 1801 && this.getMinAccur() == mRangedBeacons.get(k).getAccuracy()) {
                    num=mRangedBeacons.get(k).getMajor();
                }
            }
        }
        return num;
    }

    static class ViewHolder {
        TextView recoProximityUuid;
        TextView recoMajor;
        TextView recoMinor;
        TextView recoTxPower;
        TextView recoRssi;
        TextView recoProximity;
        TextView recoAccuracy;
    }
}

