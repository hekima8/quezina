package com.example.admin.demo8;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

/**
 * Created by admin on 2016-08-19.
 */

/**
 * 저장한 쿠폰이미지 리스트 보여주기 - 누르면 바코드랑 사진 뜨기*/
public class CouponhamActivity extends Activity implements View.OnClickListener {
    Typeface typeface;
    //Integer[] couponID = {R.drawable.coupon1, R.drawable.coupon2, R.drawable.coupon3};
    Integer couponID;
    //String[] couponSub = {"스낵류 쿠폰", "라면/즉석밥 쿠폰", "통조림/소스류 쿠폰"};
    String couponSub;
    DBHandler handler;
    ImageView coupons;
    //Button back;
    Button backbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coupon);
        coupons = (ImageView) findViewById(R.id.coupons);

        //setTitle("MY 쿠폰함");
        handler = DBHandler.open(this);

        Intent intent = getIntent();
        String id = intent.getStringExtra("홈의 아이디");

        Cursor cursor = handler.select(id);
        startManagingCursor(cursor);

        if (cursor.getCount() == 0) {
            Toast.makeText(this, id + " 는 저장된 쿠폰이 없습니다.", Toast.LENGTH_SHORT).show();
        } else {
            String couponNum = cursor.getString(cursor.getColumnIndex("coupon_name"));
            Toast.makeText(this, id + " 의 쿠폰 번호 " + couponNum, Toast.LENGTH_SHORT).show();


            if (couponNum.equals("1")) {
                coupons.setImageResource(R.drawable.coupon1);
                couponID = R.drawable.coupon1;
                couponSub = "스낵류 쿠폰";
            } else if (couponNum.equals("2")) {
                coupons.setImageResource(R.drawable.coupon2);
                couponID = R.drawable.coupon2;
                couponSub = "라면/즉석밥 쿠폰";
            } else {
                coupons.setImageResource(R.drawable.coupon3);
                couponID = R.drawable.coupon3;
                couponSub = "통조림/소스류 쿠폰";
            }
        }
        handler.close();

        /*
        coupons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View dialogView = (View) View.inflate(CouponhamActivity.this, R.layout.dialog, null);
                AlertDialog.Builder dlg = new AlertDialog.Builder(CouponhamActivity.this);
                ImageView ivPoster = (ImageView) dialogView.findViewById(R.id.couponClick);
                ivPoster.setImageResource(couponID);
                dlg.setTitle(couponSub);
                dlg.setIcon(R.drawable.cartlogo);
                dlg.setView(dialogView);
                dlg.setNegativeButton("닫기", null);
                dlg.show();
            }
        });
        */

        /*
        final GridView gv = (GridView) findViewById((R.id.gridView));
        MyGridAdapter gAdapter = new MyGridAdapter(this);
        gv.setAdapter(gAdapter);
        */
    }
    @Override
    public void onClick(View v) {
        //backbtn = (Button) findViewById(R.id.backbtn);
        switch (v.getId()) {
            //case R.id.backbtn:
               // finish();
                //startActivity(new Intent(CouponhamActivity.this, HomeActivity.class));
               // break;
            case R.id.coupons:
                View dialogView = (View) View.inflate(CouponhamActivity.this, R.layout.dialog, null);
                AlertDialog.Builder dlg = new AlertDialog.Builder(CouponhamActivity.this);
                ImageView ivPoster = (ImageView) dialogView.findViewById(R.id.couponClick);
                ivPoster.setImageResource(couponID);
                dlg.setTitle(couponSub);
                dlg.setIcon(R.drawable.cartlogo);
                dlg.setView(dialogView);
                dlg.setNegativeButton("닫기", null);
                dlg.show();
                break;
        }
    }


    /*
    public class MyGridAdapter extends BaseAdapter {
        Context context;

        public MyGridAdapter(Context c) {
            context = c;
        }

        @Override
        public int getCount() {
            return 1;
        }


        @Override
        public Object getItem(int position) {
            return couponID;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final int pos = position;
            //백버튼

            ImageView imageView = new ImageView(context);
            imageView.setLayoutParams(new GridView.LayoutParams(500, 600));
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            imageView.setPadding(5, 5, 5, 5);

            imageView.setImageResource(couponID);

            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    View dialogView = (View) View.inflate(CouponhamActivity.this, R.layout.dialog, null);
                    AlertDialog.Builder dlg = new AlertDialog.Builder(CouponhamActivity.this);
                    ImageView ivPoster = (ImageView) dialogView.findViewById(R.id.couponClick);
                    ivPoster.setImageResource(couponID);
                    dlg.setTitle(couponSub);
                    dlg.setIcon(R.drawable.cartlogo);
                    dlg.setView(dialogView);
                    dlg.setNegativeButton("닫기", null);
                    dlg.show();
                }
            });
            return imageView;
        }
    }
    */
}
