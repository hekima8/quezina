package com.example.admin.demo8;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Looper;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

//import com.loopj.android.http.AsyncHttpClient;
//import com.loopj.android.http.PersistentCookieStore;
//import com.loopj.android.http.RequestParams;

//import org.apache.http.impl.client.DefaultHttpClient;
//import com.loopj.android.http.AsyncHttpClient;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.PersistentCookieStore;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{
    EditText id, passwd;
    List<NameValuePair> nameValuePairList;
    ProgressDialog dialog = null;
    HttpPost httpPost;
    HttpResponse response;
    HttpClient httpclient;
    String inputid = "";
    //RequestParams params = new RequestParams();
    HttpClientt hcc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Log.i("Start", "start");

        //setTitle("로그인");
        //setTheme(android.R.style.Theme_NoTitleBar);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy); //강제적으로 네트워크 접속

        Typeface typeface = Typeface.createFromAsset(getAssets(), "210L.ttf"); //글꼴설정

        Button login_btn=(Button) findViewById(R.id.login_button);
        login_btn.setOnClickListener(this);
        Button join_btn=(Button) findViewById(R.id.join_button);
        join_btn.setOnClickListener(this);

        id = (EditText) findViewById(R.id.loginid);
        passwd = (EditText) findViewById(R.id.loginpw);

        id.setTypeface(typeface);
        passwd.setTypeface(typeface);
        login_btn.setTypeface(typeface);
        join_btn.setTypeface(typeface);

        HttpClientt hc = new HttpClientt();
        AsyncHttpClient client = hc.getInstance();
        PersistentCookieStore myCookieStore = new PersistentCookieStore(this);
        client.setCookieStore(myCookieStore);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.login_button:
                dialog = ProgressDialog.show(LoginActivity.this, "", "Validating user...", true);
                //로그인버튼 누르고 잠시 기다리는 동안 출력되는 다이얼로그
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Looper.prepare();
                        login();
                        Looper.loop();
                    }
                }).start();

                break;
            case R.id.join_button:
                startActivity(new Intent(LoginActivity.this, JoinActivity.class));
                break;
        }
    }
    void login() {

        try{
            //httpclient = new DefaultHttpClient();
            httpclient = SessionControl.getHttpclient();

            inputid = id.getText().toString();

            hcc = new HttpClientt();
            httpPost = new HttpPost(hcc.addr+"/changsun/logcheck.php");
            nameValuePairList = new ArrayList<>(2);
            nameValuePairList.add(new BasicNameValuePair("id", inputid));
            nameValuePairList.add(new BasicNameValuePair("passwd", passwd.getText().toString()));

            httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairList));
            response = httpclient.execute(httpPost);


            ResponseHandler<String> responseHandler = new BasicResponseHandler();
            final String response = httpclient.execute(httpPost, responseHandler);
            System.out.println("Response : "+response); //요청이 제대로 됐는지 확인
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    dialog.dismiss();
                }
            });

            if(response.equalsIgnoreCase("User Found")){
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(LoginActivity.this, "로그인 성공", Toast.LENGTH_SHORT).show();
                        //Toast.makeText(getApplicationContext(), "null", Toast.LENGTH_SHORT).show();
                    }
                });
                SessionControl.cookies = SessionControl.httpclient.getCookieStore().getCookies();

                //읽어온 쿠키값을 한번 출력 하여 보자.
                Cookie cookie;
                if (!SessionControl.cookies.isEmpty())
                {
                    for (int i = 0; i < SessionControl.cookies.size(); i++)
                    {
                        cookie = SessionControl.cookies.get(i);
                        //Log.v("TAG","===>>>"+ cookie.toString() );
                        Log.v(cookie.getName()+" 의 쿠키값" ,"===>>>"+ cookie.getValue().toString() );
                    }
                }
                Intent intent = new Intent(this, HomeActivity.class);
                intent.putExtra("입력한 id", inputid);
                startActivity(intent);
                //startActivity(new Intent(LoginActivity.this, HomeActivity.class)); //로그인 성공 시 홈 액티비티로 넘어감
                finish();
            } else {
                Toast.makeText(LoginActivity.this, "로그인 실패하였습니다. 다시 입력해주세욧", Toast.LENGTH_SHORT).show();
            }
    }catch (Exception e){
            dialog.dismiss();
            System.out.println("Exception: "+e.getMessage());
        }
    }
}

