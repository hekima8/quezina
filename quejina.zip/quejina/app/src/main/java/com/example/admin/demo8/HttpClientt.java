package com.example.admin.demo8;

import com.loopj.android.http.*;

/**
 * Created by admin on 2016-08-11.
 */
public class HttpClientt {
    public static String BASE_URL = "http://10.200.176.26";
    public String addr = "http://10.200.176.26";

    private static AsyncHttpClient client = new AsyncHttpClient();

    public static AsyncHttpClient getInstance() {
        return HttpClientt.client;
    }
    public static void get(String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        client.get(getAbsoluteUrl(url), params, responseHandler);
    }
    public static void post(String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        client.post(getAbsoluteUrl(url), params, responseHandler);
    }
    private static String getAbsoluteUrl(String relativeUrl) {
        return BASE_URL+relativeUrl;
    }
}
