package com.example.admin.demo8;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStream;
import java.net.URL;
import java.net.URLEncoder;

public class JoinActivity extends AppCompatActivity {
    //마지막으로 뒤로가기 버튼이 터치된 시간
    private long lastTimeBackPressed;
    Button joinOK, joinCancel;
    TextView tid, tpw, tsex, tage;
    EditText editid, editpasswd,editage;
    String sex;

    private static final String SERVER_ADDR =  "http://10.200.176.26/changsun";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);
        //setTitle("회원가입");

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        //url.openStream 부분 에러 잡아줌. 강제적으로 네트워크 사용

        Typeface typeface = Typeface.createFromAsset(getAssets(), "210L.ttf"); //글꼴설정

        joinOK = (Button) findViewById(R.id.button1);
        joinCancel = (Button) findViewById(R.id.button2);

        editid = (EditText) findViewById(R.id.editid);
        editpasswd = (EditText) findViewById(R.id.editpasswd);
        //editsex = (EditText) findViewById(R.id.editsex);
        editage = (EditText) findViewById(R.id.editage);

        tid = (TextView) findViewById(R.id.id);
        tpw = (TextView) findViewById(R.id.pw);
        tage = (TextView) findViewById(R.id.age);
        tsex = (TextView) findViewById(R.id.sex);

        RadioGroup sexGroup = (RadioGroup)findViewById(R.id.sexgroup);
        sexGroup.setOnCheckedChangeListener(mRadioCheck);

        joinOK.setTypeface(typeface);
        joinCancel.setTypeface(typeface);
        tid.setTypeface(typeface);
        tpw.setTypeface(typeface);
        tage.setTypeface(typeface);
        tsex.setTypeface(typeface);

        joinOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editid.getText().toString().equals("")
                        || editpasswd.getText().toString().equals("")
                        || editage.getText().toString().equals("")) {
                    Toast.makeText(JoinActivity.this, "항목을 다 채워주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String id = editid.getText().toString();
                        String passwd = editpasswd.getText().toString();
                        //String sex = editsex.getText().toString();
                        String birth = editage.getText().toString();

                        try{
                            URL url = new URL(SERVER_ADDR + "/join.php?"
                            + "id="+ URLEncoder.encode(id, "UTF-8")
                            + "&passwd="+URLEncoder.encode(passwd, "UTF-8")
                            + "&sex="+URLEncoder.encode(sex, "UTF-8")
                            + "&age="+URLEncoder.encode(birth, "UTF-8"));

                            url.openStream();
                            //입력받은 아이디, 패스워드를 DB로 보내기 위해 url 구성

                            String result = getXmlData("insertresult.xml", "result");

                            if(result.equals("1")) {
                                Toast.makeText(JoinActivity.this, "가입완료! 로그인하세요", Toast.LENGTH_SHORT).show();

                                editid.setText("");
                                editpasswd.setText("");
                                //editsex.setText("");
                                editage.setText("");
                            }else {
                                Toast.makeText(JoinActivity.this, "회원가입 실패", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(JoinActivity.this, JoinActivity.class));
                                finish();
                            }
                            startActivity(new Intent(JoinActivity.this, LoginActivity.class));
                            finish();
                        } catch (Exception e) {
                            Log.e("Error", e.getMessage());
                        }
                    }

                });
            }
        });
        joinCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(JoinActivity.this, LoginActivity.class));
            }
        });

    }

    RadioGroup.OnCheckedChangeListener mRadioCheck =
            new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    if (group.getId() == R.id.sexgroup) {
                        switch (checkedId) {
                            case R.id.male:
                                //Toast.makeText(JoinActivity.this, "남자", Toast.LENGTH_SHORT).show();
                                sex = "male";
                                break;
                            case R.id.female:
                                //Toast.makeText(JoinActivity.this, "여자", Toast.LENGTH_SHORT).show();
                                sex = "female";
                                break;
                        }
                    }
                }
            };

    /** XML 파싱 부분 */
    private String getXmlData(String filename, String str) {
        String rss = SERVER_ADDR + "/";
        String ret = "";

        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser xpp = factory.newPullParser();
            URL server = new URL(rss+filename);
            InputStream is = server.openStream();
            xpp.setInput(is, "UTF-8");

            int eventType = xpp.getEventType();

            while(eventType != XmlPullParser.END_DOCUMENT) {
                if(eventType == XmlPullParser.START_TAG) {
                    if(xpp.getName().equals(str)) {
                        ret = xpp.nextText();
                    }
                }
                eventType = xpp.next();
            }
        } catch (Exception e) {
            Log.e("Error", e.getMessage());
        }
        return ret;
    }

    @Override
    public void onBackPressed() {
        //1.5초 이내에 뒤로가기 버튼을 또 터치했으면 앱을 종료한다.
        if(System.currentTimeMillis()-lastTimeBackPressed<1500){
            finish();
            return;
        }
        Toast.makeText(this, "'뒤로' 버튼을 한번 더 누르면 종료됩니다.", Toast.LENGTH_SHORT).show();

        //사용자가 뒤로가기 버튼을 터치할 때마다 현재시간을 기록해둔다.
        lastTimeBackPressed = System.currentTimeMillis();
    }

}
