package com.example.admin.demo8;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

/**
 * Created by admin on 2016-08-09.
 */
public class PopupActivity extends Activity {
    Button saveBtn;
    Intent intent1;
    String couponNum;
    Typeface typeface;
    DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND, WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
        setContentView(R.layout.activity_popup);
        dbHandler=DBHandler.open(this);

        ImageView imageView = (ImageView) findViewById(R.id.couponPopup);
        intent1 = getIntent();
        couponNum = intent1.getStringExtra("쿠폰");

        typeface = Typeface.createFromAsset(getAssets(), "210L.ttf"); //글꼴설정

        Log.v("받아온 쿠폰번호 :::::", couponNum);

        if(couponNum.equals("1")){
            imageView.setImageResource(R.drawable.coupon1);
        } else if(couponNum.equals("2")){
            imageView.setImageResource(R.drawable.coupon2);
        } else {
            imageView.setImageResource(R.drawable.coupon3);
        }

        /*
        WebView webView = (WebView)findViewById(R.id.webPopup);
        webView.setWebViewClient(new myWebViewClient());
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setBuiltInZoomControls(true);
        webView.loadUrl("http://10.200.12.39/coupon.jpg");
*/

        saveBtn = (Button) findViewById(R.id.saveButton);
        saveBtn.setTypeface(typeface);
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //쿠폰 저장 - 로그인 액티비티에서 인텐트로 보낸 아이디랑 홈액티비티에서 온 쿠폰이름으로
                Intent intent = getIntent();
                String id = intent.getStringExtra("홈에서보낸아이디");
                long cnt = dbHandler.insert(id, couponNum);
                if(cnt == -1) {
                    Toast.makeText(getApplicationContext(), id+"의 쿠폰 "+couponNum+"이 저장되지 않았습니다.", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(getApplicationContext(),id+"의 쿠폰 "+couponNum+"이 저장되었습니다..", Toast.LENGTH_SHORT).show();
                }
                finish();
            }
        });
    }
/*
    class myWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            // TODO Auto-generated method stub
            view.loadUrl(url);
            return true;
        }
    }
    */
}