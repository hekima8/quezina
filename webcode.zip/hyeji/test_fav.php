<?php
// Scatterplot with colors example 2013-11-14
require_once 'phplot.php';

// Assume this is the result of a database query, perhaps something like
// this: SELECT xval, yval, mode FROM mytable ...
// Use 'mode' for the color, with values 1, 2, and 3.
// X Y Mode
$two = 3; $three = 0; $four = 5; $five = 0; $six = 0; $seven = 1; $eight = 2; $nine = 0; $ten = 4;
$names = array('1st', '2nd', '3rd', '4th', '5th');

$results = array(
array( 9, 160, $two),
array( 325, 160, $two),
array( 325, 320, $two),
array( 9, 320, $two),
array( 9, 160, $two),
array( 9, 325, $three),
array( 325, 325, $three),
array( 325, 478, $three),
array( 9, 478, $three),
array( 9, 325, $three),
array( 9, 483, $four),
array( 325, 483, $four),
array( 325, 630, $four),
array( 9, 630, $four),
array( 9, 483, $four),
array( 330, 160, $five),
array( 650, 160, $five),
array( 650, 320, $five),
array( 330, 320, $five),
array( 330, 160, $five),
array( 330, 325, $six),
array( 650, 325, $six),
array( 650, 478, $six),
array( 330, 478, $six),
array( 330, 325, $six),
array( 330, 483, $seven),
array( 650, 483, $seven),
array( 650, 630, $seven),
array( 330, 630, $seven),
array( 330, 483, $seven),
array( 655, 160, $eight),
array( 975, 160, $eight),
array( 975, 320, $eight),
array( 655, 320, $eight),
array( 655, 160, $eight),
array( 655, 325, $nine),
array( 975, 325, $nine),
array( 975, 478, $nine),
array( 655, 478, $nine),
array( 655, 325, $nine),
array( 655, 483, $ten),
array( 975, 483, $ten),
array( 975, 630, $ten),
array( 655, 630, $ten),
array( 655, 483, $ten),
);

// Make a PHPlot data array for a points plot, slotting the Y value in one
// of 3 columns according to the mode, in order to get 3 colors:
$data = array();
foreach ($results as $result_row) {
// Make a row with empty label, X, and Y in one of the 3 Y columns:
$row = array('', $result_row[0], '', '', '', '', '');
$row[$result_row[2] + 1] = $result_row[1];
$data[] = $row;
}

// Make a points plot using the above data:
$plot = new PHPlot(1000, 700);
$plot->SetDataType('data-data');
$plot->SetPlotAreaWorld(0,0,1000,700);
$plot->SetXtickIncrement(20);
$plot->SetYtickIncrement(20);
$plot->SetBgImage('aa.jpg', 'scale');
$plot->SetDataValues($data);
$plot->SetPlotType('lines');

$plot->SetDrawXGrid(False);
$plot->SetDrawYGrid(False);

$plot->SetLegendPosition(1, 1, 'plot', 1, 1, -17, -17);
$plot->SetLineWidths(5);
// Set colors for 3 data sets:
$plot->SetDataColors(array('red', 'purple','navy', 'YellowGreen', 'orange'));

$plot->SetLegend($names);
$plot->SetFont('legend', 5);

// Use the same point shape for all data sets:
#$plot->SetPointShapes('dot');
$plot->DrawGraph();

