<?php  
require_once 'phplot.php';

$plot = new PHPlot(1500, 700);

$plot->SetPrintImage(0);

mysql_connect("localhost", "root", "root") or die (mysql_error());
mysql_select_db("test");
 
$sql = "SELECT * FROM longterm"; //id 입력
$result = mysql_query( $sql ) or die (mysql_error());

$a = 0; $b = 0; $c = 0; $d = 0; $e = 0; $f = 0; $g = 0; $h = 0; $i = 0;

while($row = mysql_fetch_array($result)) {

	$cnt = array("one","two","three","four","five","six","seven","eight","nine","ten");
	
	$a += $row[$cnt[1]];
	$b += $row[$cnt[2]];
	$c += $row[$cnt[3]];
	$d += $row[$cnt[4]];
	$e += $row[$cnt[5]];
	$f += $row[$cnt[6]];
	$g += $row[$cnt[7]];
	$h += $row[$cnt[8]];
	$i += $row[$cnt[9]];
	//foreach ($count as $x => $x_value) {
	//	$x_value = $i++;
	//}
}

$count = array(1 => $a, 2 => $b, 3 => $c, 4 => $d, 5 => $e, 6 => $f, 7 => $g, 8 => $h, 9 => $i);
arsort($count);

$num = 1;
foreach($count as $x=>$x_value) {
	if ($num==6)
		break;
	switch ($x) {
		case 1:
			$two = $num;
			break;
		case 2:
			$three = $num;
			break;
		case 3:
			$four = $num;
			break;
		case 4:
			$five = $num;
			break;
		case 5:
			$six = $num;
			break;
		case 6:
			$seven = $num;
			break;
		case 7:
			$eight = $num;
			break;
		case 8:
			$nine = $num;
			break;
		case 9:
			$ten = $num;
			break;
	}
	$num++;
}


$results = array(
array( 9, 160, $nine),
array( 325, 160, $nine),
array( 325, 320, $nine),
array( 9, 320, $nine),
array( 9, 160, $nine),
array( 9, 325, $nine),
array( 325, 325, $nine),
array( 325, 478, $nine),
array( 9, 478, $nine),
array( 9, 325, $nine),
array( 9, 483, $ten),
array( 325, 483, $ten),
array( 325, 630, $ten),
array( 9, 630, $ten),
array( 9, 483, $ten),
array( 330, 160, $seven),
array( 650, 160, $seven),
array( 650, 320, $seven),
array( 330, 320, $seven),
array( 330, 160, $seven),
array( 330, 325, $six),
array( 650, 325, $six),
array( 650, 478, $six),
array( 330, 478, $six),
array( 330, 325, $six),
array( 330, 483, $five),
array( 650, 483, $five),
array( 650, 630, $five),
array( 330, 630, $five),
array( 330, 483, $five),
array( 655, 160, $two),
array( 975, 160, $two),
array( 975, 320, $two),
array( 655, 320, $two),
array( 655, 160, $two),
array( 655, 325, $three),
array( 975, 325, $three),
array( 975, 478, $three),
array( 655, 478, $three),
array( 655, 325, $three),
array( 655, 483, $four),
array( 975, 483, $four),
array( 975, 630, $four),
array( 655, 630, $four),
array( 655, 483, $four),
);

// Make a PHPlot data array for a points plot, slotting the Y value in one
// of 3 columns according to the mode, in order to get 3 colors:
$data = array();
foreach ($results as $result_row) {
// Make a row with empty label, X, and Y in one of the 3 Y columns:
$row = array('', $result_row[0], '', '', '', '', '');
$row[$result_row[2] + 1] = $result_row[1];
$data[] = $row;
}

// Make a points plot using the above data:
$plot = new PHPlot(1000, 700);
$plot->SetDataType('data-data');
$plot->SetPlotAreaWorld(0,0,1000,700);
$plot->SetXtickIncrement(1000);
$plot->SetYtickIncrement(700);
$plot->SetBgImage('aa.jpg', 'scale');
$plot->SetDataValues($data);
$plot->SetPlotType('lines');

$plot->SetDrawXGrid(False);
$plot->SetDrawYGrid(False);
$plot->SetXtickLabelPos('none');
$plot->SetYtickLabelPos('none');

$plot->SetLegendPosition(1, 1, 'plot', 1, 1, -17, -17);
$plot->SetLineWidths(5);
// Set colors for 3 data sets:
$plot->SetDataColors(array('red', 'purple','navy', 'YellowGreen', 'orange'));


$names = array('1st', '2nd', '3rd', '4th', '5th');
$plot->SetLegend($names);
$plot->SetFont('legend', 5);

// Use the same point shape for all data sets:
#$plot->SetPointShapes('dot');
$plot->DrawGraph();



?> 