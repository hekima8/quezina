<?php
require_once 'phplot.php';

$plot = new PHPlot(1500, 700);

$plot->SetPrintImage(0);

mysql_connect("localhost", "root", "root") or die (mysql_error());
mysql_select_db("test");
 
// DB¿¡¼­ µ¥ÀÌÅÍ¸¦ ºÒ·¯¿À±â À§ÇÑ Äõ¸®¹® ÀÔ´Ï´Ù. CASE¹®ÀÌ ¾²¿©¼­ Á¶±Ý ¾î·Æ°Ô ´À²¸Áö½Ç ¼öµµ ÀÖ°Ú³×¿ä.
// CASE ¹®¹ý¿¡ ´ëÇØ¼­ »ìÆìº¸½Ã°í ³Ñ¾î°¡½Ã±â ¹Ù¶ø´Ï´Ù. Àú´Â MSSQL°ú ¹®¹ýÀÌ ´Þ¶ó Á¶±Ý Çì¸å½À´Ï´Ù.  
$sql = "SELECT * FROM lib_1"; //id 입력
$result = mysql_query( $sql ) or die (mysql_error());
$indx = 0;
$old = "";
$temp = "";

$bfr="";
$bbfr="";

$oneD=0; $twoD=0; $threeD=0; $fourD=0; $fiveD=0; $sixD=0; $sevenD=0; $eightD=0; $nineD=0; $tenD=0;
$oneC=0; $twoC=0; $threeC=0; $fourC=0; $fiveC=0; $sixC=0; $sevenC=0; $eightC=0; $nineC=0; $tenC=0;

$x = array(200, 150, 111, 22, 119);
$y = array(22, 52, 75, 98, 120, 22, 120);

$diff=3;

$i=0;

while($row = mysql_fetch_array($result))
{
	$temp="";
	$min=100;
	$cnt = array("one","two","three","four","five","six","seven","eight","nine","ten");
	for ($i=0; $i<10; $i++)       
	{
		if($min >= $row[$cnt[$i]] && $row[$cnt[$i]] != "none") {
			$min = $row[$cnt[$i]];
			$temp = $cnt[$i];
			
		}
	}
	if (strcmp($temp, $old)==0 && strcmp($temp, "")!=0)
	{	
		switch ($temp) {
		case "one" : 	
			if ($bfr=='two' && $bbfr!='three' && $oneD!=0){
				$data[$indx++] = array('', $x[1], $y[1]);
				$data[$indx++] = array('', $x[1]+$diff, $y[1]);
				$x[1] += $diff;		
				$data[$indx++] = array('', $x[1], $y[0]+$diff);
				$data[$indx++] = array('', $x[0], $y[0]+$diff);
				$y[0] += $diff;
				$oneD++;	
			}else if ($bfr=='two' && $oneD!=0){
				$data[$indx++] = array('', $x[1], $y[0]+$diff);
				$data[$indx++] = array('', $x[0], $y[0]+$diff);
				$y[0] += $diff;
				$oneD++;	
			}else if ($bfr=='two') {
				$data[$indx++] = array('', $x[1], $y[0]);
				$data[$indx++] = array('', $x[0], $y[0]);
				$oneD++;
			}
			else if ($bfr!='one') {
				$data[$indx++] = array('', $x[0], $y[0]);
				$oneD++;
			}
			$bbfr=$bfr;
			$bfr="one";
			$oneC++;
			break;

		case "two" :
			if ($bfr=='one' && $twoD!=0) {
				$data[$indx++] = array('', $x[0], $y[0]+$diff);
				$y[0] += $diff; 
				$data[$indx++] = array('', $x[1]+$diff, $y[0]);
				$data[$indx++] = array('', $x[1]+$diff, $y[1]);
				$x[1] += $diff;
				$twoD++;
			}else if ($bfr=='one') {
				$data[$indx++] = array('', $x[1], $y[0]);
				$data[$indx++] = array('', $x[1], $y[1]);
				$twoD++;
			}else if ($bfr=='three' && $twoD!=0){
				$data[$indx++] = array('', $x[1]+$diff, $y[2]);
				$x[1] += $diff;
				$data[$indx++] = array('', $x[1], $y[1]);
				$twoD++;
			}else if ($bfr=='seven' && $twoD!=0){
				$data[$indx++] = array('', $x[2]-$diff, $y[1]);
				$x[2] -= $diff;
				$data[$indx++] = array('', $x[2], $y[0]+$diff);
				$data[$indx++] = array('', $x[1]+$diff, $y[0]+$diff);
				$data[$indx++] = array('', $x[1]+$diff, $y[1]);
				$x[1] += $diff;
				$y[0] += $diff;
				$fiveD++;
			}else if ($bfr=='seven'){
				$data[$indx++] = array('', $x[2], $y[0]);
				$data[$indx++] = array('', $x[1], $y[0]);
				$data[$indx++] = array('', $x[1], $y[1]);
				$twoD++;
			}else if ($bfr!='two') {
				$data[$indx++] = array('', $x[1], $y[1]);
				$twoD++;
			}

			$twoC++;
			$bbfr=$bfr;
			$bfr='two';
			break;		
		case "three" : 
			if ($bfr=='two' && $bbfr!='one' && $bbfr!='seven' && $threeD!=0){
				$data[$indx++] = array('', $x[1]+$diff, $y[1]);
				$x[1] += $diff;
				$data[$indx++] = array('', $x[1], $y[2]);
				$threeD++;
			}else if ($bfr=='four' && $threeD!=0){
				$data[$indx++] = array('', $x[1]+$diff, $y[3]);
				$data[$indx++] = array('', $x[1]+$diff, $y[2]);
				$x[1] += $diff;
				$threeD++;
			}else if ($bfr!='three') {	
				$data[$indx++] = array('', $x[1], $y[2]);
				$threeD++;
			}
			$threeC++;
			$bbfr=$bfr;
			$bfr='three';
			break;
		case "four" : 
			if ($bfr=='five' && $fourD!=0){
				$data[$indx++] = array('', $x[2]-$diff, $y[3]);
				$x[2] -= $diff;
				$data[$indx++] = array('', $x[2], $y[4]+$diff);
				$data[$indx++] = array('', $x[1]+$diff, $y[4]+$diff);
				$x[1] += $diff;
				$y[4] += $diff;
				$data[$indx++] = array('', $x[1], $y[3]);
				$fourD++;
			}else if ($bfr=='five'){
				$data[$indx++] = array('', $x[2], $y[4]);
				$data[$indx++] = array('', $x[1], $y[4]);
				$data[$indx++] = array('', $x[1], $y[3]);
				$fourD++;
			}else if ($bfr=='three' && $bbfr!='two' && $fourD!=0) {
				$data[$indx++] = array('', $x[1]+$diff, $y[2]);
				$data[$indx++] = array('', $x[1]+$diff, $y[3]);
				$x[1] += $diff;
				$fourD++;
			}else if ($bfr!='four') {	
				$data[$indx++] = array('', $x[1], $y[3]);
				$fourD++;
			}
			$fourC++;
			$bbfr=$bfr;
			$bfr='four';
			break;
		case "five" : 
			if ($bfr=='four' && $bbfr!='three' && $fiveD!=0){
				$data[$indx++] = array('', $x[1]+$diff, $y[3]);
				$x[1] += $diff;
				$data[$indx++] = array('', $x[1], $y[4]+$diff);
				$data[$indx++] = array('', $x[2]-$diff, $y[4]+$diff);
				$x[2] -= $diff;
				$y[4] += $diff;
				$data[$indx++] = array('', $x[2], $y[3]);
				$fiveD++;
			}else if ($bfr=='four' && $fiveD==0){
				$data[$indx++] = array('', $x[1], $y[4]);
				$data[$indx++] = array('', $x[2], $y[4]);
				$data[$indx++] = array('', $x[2], $y[3]);
				$y[4] += $diff;
				$fiveD++;
			}else if ($bfr=='four' && $bbfr=='three'){
				$data[$indx++] = array('', $x[1], $y[4]);
				$x[2] -= $diff;
				$data[$indx++] = array('', $x[2], $y[4]);
				$data[$indx++] = array('', $x[2], $y[3]);
				$y[4] += $diff;
				$fiveD++;
			}elseif ($bfr=='four'){
				$data[$indx++] = array('', $x[1], $y[4]);
				$data[$indx++] = array('', $x[2], $y[4]);
				$data[$indx++] = array('', $x[2], $y[3]);
				$fiveD++;
			}else if ($bfr=='six' && ($bbfr=='seven' || $bbfr=='six')){
				$data[$indx++] = array('', $x[2], $y[2]);
				$data[$indx++] = array('', $x[2], $y[3]);
				$fiveD++;
			}else if ($bfr=='ten' && $fiveD!=0 && ($bbfr=='nine' || $bbfr=='ten')) {
				$y[6] += $diff;
				$data[$indx++] = array('', $x[3], $y[3]);
				$data[$indx++] = array('', $x[3], $y[6]);
				$data[$indx++] = array('', $x[2], $y[6]);
				$data[$indx++] = array('', $x[2], $y[3]);
				$sixD++;
			}else if ($bfr=='ten') {
				$data[$indx++] = array('', $x[3], $y[6]);
				$data[$indx++] = array('', $x[2], $y[6]);
				$data[$indx++] = array('', $x[2], $y[3]);
				$sixD++;
			}else if ($bfr!='five') {	
				$data[$indx++] = array('', $x[2], $y[3]);
				$fiveD++;
			}
			$fiveC++;
			$bbfr=$bfr;
			$bfr='five';
			break;
		case "six" : 
			if ($bfr=='five' && $bbfr!='four' && $sixD!=0){
				$data[$indx++] = array('', $x[2]-$diff, $y[3]);
				$data[$indx++] = array('', $x[2]-$diff, $y[2]);
				$x[2] -= $diff;
				$sixD++;
			}else if ($bfr=='seven' && $bbfr!='eight'){
				$data[$indx++] = array('', $x[2]-$diff, $y[1]);
				$data[$indx++] = array('', $x[2]-$diff, $y[2]);
				$x[2] -= $diff;
				$sixD++;
			}else if ($bfr!='six') {	
				$data[$indx++] = array('', $x[2], $y[2]);
				$sixD++;
			}
			$sixC++;
			$bbfr=$bfr;
			$bfr='six';
			break;
		case "seven" :
			if ($bfr=='six' && $bbfr!='five'){
				$data[$indx++] = array('', $x[2]-$diff, $y[2]);
				$data[$indx++] = array('', $x[2]-$diff, $y[1]);
				$x[2] -= $diff;
				$sevenD++;
			}else if ($bfr=='eight' && $sevenD!=0){
				$data[$indx++] = array('', $x[3]+$diff, $y[1]);
				$x[3] += $diff;
				$data[$indx++] = array('', $x[3], $y[5]+$diff);
				$data[$indx++] = array('', $x[2]-$diff, $y[5]+$diff);
				$x[2] -= $diff;
				$y[5] += $diff;
				$data[$indx++] = array('', $x[2], $y[1]);
				$sevenD++;
			}else if ($bfr=='eight'){
				$data[$indx++] = array('', $x[3], $y[1]);
				$data[$indx++] = array('', $x[3], $y[5]);
				$data[$indx++] = array('', $x[2], $y[5]);
				$data[$indx++] = array('', $x[2], $y[1]);
				$sevenD++;
			}else if ($bfr!='seven') {	
				$data[$indx++] = array('', $x[2], $y[1]);
				$sevenD++;
			}
			$sevenC++;
			$bbfr=$bfr;
			$bfr='seven';
			break;
		case "eight" :
			if ($bfr=='seven' && $bbfr=='eight' && $eightD!=0) {
				$data[$indx++] = array('', $x[2]-$diff, $y[1]);
				$data[$indx++] = array('', $x[2]-$diff, $y[5]+$diff);
				$data[$indx++] = array('', $x[3]+$diff, $y[5]+$diff);
				$x[2] -= $diff;
				$y[5] += $diff;
				$x[3] += $diff;
				$data[$indx++] = array('', $x[3], $y[1]);
				$eightD++;
			}else if ($bfr=='nine' && $bbfr=='ten'){
				$data[$indx++] = array('', $x[3], $y[1]);
				$eightD++;	
			}else if ($bfr=='seven' && $eightD!=0) {
				$data[$indx++] = array('', $x[2], $y[5]+$diff);
				$data[$indx++] = array('', $x[3]+$diff, $y[5]+$diff);
				$y[5] += $diff;
				$x[3] += $diff;
				$data[$indx++] = array('', $x[3], $y[1]);
				$eightD++;
			}else if ($bfr=='seven') {
				$data[$indx++] = array('', $x[2], $y[5]);
				$data[$indx++] = array('', $x[3], $y[5]);
				$data[$indx++] = array('', $x[3], $y[1]);
				$eightD++;
			}else if ($bfr=='nine') {
				$data[$indx++] = array('', $x[3]+$diff, $y[2]);
				$data[$indx++] = array('', $x[3]+$diff, $y[1]);
				$x[3] += $diff;
				$eightD++;
			}else if ($bfr!='eight') {	
				$data[$indx++] = array('', $x[3], $y[1]);
				$eightD++;
			}
			$eightC++;
			$bbfr=$bfr;
			$bfr='eight';
			break;
		case "nine" :
			if ($bfr=='eight' && $nineD!=0) {
				$data[$indx++] = array('', $x[3]+$diff, $y[1]);
				$data[$indx++] = array('', $x[3]+$diff, $y[2]);
				$x[3] += $diff;
				$nineD++;
			}else if ($bfr=='ten' && $nineD!=0) {
				$data[$indx++] = array('', $x[3]+$diff, $y[3]);
				$data[$indx++] = array('', $x[3]+$diff, $y[2]);
				$x[3] += $diff;
				$nineD++;
			}else if ($bfr!='nine'){
				$data[$indx++] = array('', $x[3], $y[2]);
				$nineD++;
			}
			$nineC++;
			$bbfr=$bfr;
			$bfr='nine';
			break;
		case "ten" : 
			if ($bfr=='nine' && $bbfr!='eight' && $bbfr!= 'nine') {
				$data[$indx++] = array('', $x[3]+$diff, $y[2]);
				$data[$indx++] = array('', $x[3]+$diff, $y[3]);
				$x[3] += $diff;
				$nineD++;
			}else if ($bfr=='five') {
				$data[$indx++] = array('', $x[2], $y[3]);
				$data[$indx++] = array('', $x[2], $y[6]);
				$x[2] -= $diff;
				$x[3] += $diff;
				$data[$indx++] = array('', $x[3], $y[6]);
				$data[$indx++] = array('', $x[3], $y[3]);
				$sixD++;
			}else if ($bfr!='ten'){
				$data[$indx++] = array('', $x[3], $y[3]);
				$tenD++;
			}
			$tenC++;
			$bbfr=$bfr;
			$bfr='ten';
			break;
		}
	}
	if(strcmp($temp, "")!=0)
		$old = $temp;

}


# Set up area for second plot:# Set up area for second plot:
$plot->SetPlotAreaPixels(10, 10, 1000, 690);


$plot->SetDataType('data-data');

$plot->SetImageBorderType('plain');
$plot->SetPlotAreaWorld(0,0,200,130);
$plot->SetPlotType('lines');
$plot->SetDataColors(array('salmon', 'green'));
$plot->SetDataValues($data);

$plot->SetLineWidths(3);
$plot->SetXtickIncrement(1500);
$plot->SetYtickIncrement(700);

#$plot->SetTitle('Moving Path');
$plot->SetBgImage('cc.jpg', 'scale');

$plot->SetDrawXGrid(True);
$plot->SetDrawYGrid(True);

$plot->SetXtickLabelPos('none');
$plot->SetYtickLabelPos('none');
$plot->DrawGraph();

# Set up area for second plot:
$data2 = array(        # Data array for bottom plot: Exports
  array('ONE', $oneC),  array('TWO', $twoC),  array('THREE', $threeC),
  array('FOUR', $fourC),  array('FIVE', $fiveC),  array('SIX', $sixC),
  array('SEVEN', $sevenC),  array('EIGHT', $eightC),  array('NINE', $nineC),
  array('TEN', $tenC)
);

# Do the second plot:
#$plot->SetImageBorderType('plain');
#$plot->SetDataType('text-data');
#$plot->SetYLabelType('printf');
# Set up area for first plot:
$plot->SetPlotAreaPixels(1050, 40, 1490, 600);

# Do the second plot:
$plot->SetDataType('text-data');
$plot->SetDataValues($data2);
$plot->SetPlotAreaWorld(0, NULL, NULL, NULL);
#$plot->SetDataColors(array('blue'));
$plot->SetXTickLabelPos('none');
$plot->SetXTickPos('none');
$plot->SetFont('x_label', 4);
$plot->SetFont('x_title', 4);
$plot->SetFont('y_title', 4);
$plot->SetYTickIncrement(1);
$plot->SetYTickLabelPos('yaxis');
#$plot->SetYTitle("PREFERENCE\ncount");
$plot->SetYTitle("PREFERENCE");
$plot->SetXTitle("BEACONS' NUMBER");
$plot->SetShading(0);

$plot->SetPlotType('bars');
$plot->DrawGraph();

# Output the image now:
$plot->PrintImage();
