<!DOCTYPE html>
<html>
<head>
	<title>
		
	</title>
	<style>

	</style>
	<meta charset="utf-8">

</head>
<body>
	<a href='./logout.php'><strong>  <img src="logout.png"></strong></a>

</body>
</html>

<?
	session_start();
	if($_SESSION['LoginID']==""){			
		echo"
			<script> window.alert('로그인 후 사용하세요'); 
			location.href('./index.html');
			</script>";
		exit;
	}

?>

