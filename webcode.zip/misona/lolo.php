
<?
	session_start();
	$_SESSION['LoginID']="";
	session_register('LoginID');
	session_destroy();
	
	header("location: ./index.html");
?>