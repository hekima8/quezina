<?

//require_once 'private.php';

$a=aaaaa;
echo 11111;
   ?>
