<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
</head>
<body>

</body>
</html>

<script> 

	var message= confirm("로그아웃 하시겠습니까?");

	if(message==true){
		location.href='./lolo.php';
	}
	else {
		history.back(1);
		exit;
	}
</script>


