
<?
	function Error($msg){//에러 메세지 출력 
		echo "
			<script> window.alert('$msg'); 
			history.back(1);
			</script>
		";
		exit ;
	}

?>
