<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
</head>
<body>

</body>
</html>

<?
	$con = mysqli_connect("localhost", "root", "root", "test");
	mysqli_set_charset($con, "utf8");

	include("./db_connect.php");

	if(mysqli_connect_errno($con)){
		echo "MySQL error : " . mysqli_connect_error();
	}

	$id=$_POST['id'];
	$pw=$_POST['pw'];

	//나의 정보 데이터 가지고 오기

	$sql = "select id, pw from admin where id='" .$id. "' and pw='".$pw."'";
	$return = mysqli_query($con, $sql);
	$result = mysqli_fetch_array($return);
	
	if(!$id) {Error("아이디를 입력하세욤.");}
	elseif(!$pw) {Error("비밀번호 입력하쇼");}

	if(!$result) {
		Error("아이디 또는 패스워드가 일치하지 않습니다.");	}

	else{
		session_start();
		$_SESSION['LoginID']=$id;
		echo"<script>
			location.href='./lets.html'
		</script>";
	}
?>
