<?php
	session_start();

	$hostname="127.0.0.1";
	$database="test";
	$username="root";
	$password="root";

	$localhost = mysql_connect($hostname, $username, $password) or trigger_error(mysql_error(), E_USER_ERROR);

	mysql_select_db($database, $localhost);

	$id = $_POST['id'];
	$passwd = $_POST['passwd'];
	//$id = ff;
	//$passwd = 1;


	$query_search = "select * from memjoin where id = '".$id."' and passwd = '".$passwd."'";
	$query_exec = mysql_query($query_search) or die(mysql_error());
	$rows = mysql_num_rows($query_exec);

	if($rows == 0) { echo "No Such User Found";	}
	else {
		echo "User Found";
		$_SESSION['LoginID'] = $id;
	//	$aa =  $_SESSION['LoginID'];

	//	$aa=$id;

	//	$sql = "insert into  $aa (time, one, two, three, four, five, six, seven, eight, nine, ten) values(0,5,0,0,0,3,0,0,4,0,0)";

	//	$return = mysql_query($sql);
		//$_SESSION["LoginID"] = 'ee';
		//echo "www";
		//echo $_SESSION["LoginID"];
	}
?>
