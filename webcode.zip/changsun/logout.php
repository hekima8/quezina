<?php
session_start();
$_SESSION['LoginID']="";
//$_SESSION[logcheck] = "";
session_unregister('LoginID');
session_destroy(); //세션 토큰 없앰
//header("location: /index.php");
?>
