<?php
	$id = $_POST['id'];

	$conn = mysql_connect("localhost", "root", "root");
	if(! $conn)
	{
		echo "Connect Fail!";
		exit;
	}
	mysql_select_db("test");

	$sql1 = "TRUNCATE TABLE $id";
	$return = mysql_query($sql1);

	if(! $return)
	{
		echo "테이블 비우기 실패....";
		echo mysql_error();
	}
	else
	{
		echo $id;
		echo "테이블 비워짐";
	}
	mysql_close();
?>
