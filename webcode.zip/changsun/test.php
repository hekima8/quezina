﻿<?php

	$time = $_POST['time']; 
	$one = $_POST['one']; 
	$two = $_POST['two']; 
	$three = $_POST['three']; 
	$four = $_POST['four']; 
	$five = $_POST['five']; 
	$six = $_POST['six']; 
	$seven = $_POST['seven']; 
	$eight = $_POST['eight']; 
	$nine = $_POST['nine']; 
	$ten = $_POST['ten'];
	$id = $_POST['id'];

	$conn = mysql_connect("localhost", "root", "root");
	if(! $conn)
	{
		echo "Connect Fail!";
		exit;
	}
	mysql_select_db("test");

	//$id = $_SESSION['LoginID'];
	//$id = $_POST['id'];

	//if($_SESSION["LoginID"]=='')
	//	$id = "ff";


	$sql = "insert into $id(time, one, two, three, four, five, six, seven, eight, nine, ten) values('$time', '$one','$two','$three', '$four', '$five', '$six', '$seven', '$eight', '$nine', '$ten')";
	$return = mysql_query($sql);

	if(! $return)
	{
		echo "안들어감...;;;....실패....";
		echo mysql_error();
	}
	else
	{
		echo "비콘값 들어감ㅋㅋㅋㅋ";
		echo $id;
	}
	mysql_close();
?>
