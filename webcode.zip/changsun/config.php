<?php
$DB['HOST']='127.0.0.1';
$DB['id']='root';
$DB['pw']='root';
$DB['db']='test';
?>