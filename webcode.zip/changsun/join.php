<?php
$con = mysql_connect("127.0.0.1:3306", "root", "root");
mysql_selectdb("test");
mysql_query("set names utf8");

$id = $_REQUEST[id];
$passwd = $_REQUEST[passwd];
$sex = $_REQUEST[sex];
$age = $_REQUEST[age];

$qry = "insert into memjoin(id, passwd, sex, age) values('$id', '$passwd', '$sex', '$age')";
$result = mysql_query($qry);

$qry1 = "create table $id(time varchar(20) not null, one varchar(30) not null, two varchar(30) not null, three varchar(30) not null, four varchar(30) not null, five varchar(30) not null, six varchar(30) not null, seven varchar(30) not null, eight varchar(30) not null, nine varchar(30) not null, ten varchar(30) not null)ENGINE=MYISAM CHARACTER SET utf8 COLLATE utf8_general_ci";
$res = mysql_query($qry1);


$xmlcode = "<?xml version = \"1.0\" encoding = \"utf-8\"?>\n";
$xmlcode .="<result>$result</result>\n";

$dir = "C:/APM_Setup/htdocs/changsun"; 
$filename = $dir."/insertresult.xml";


file_put_contents($filename, $xmlcode); 
?>
