﻿<?php 

$oneC = $_POST['oneC'];
$twoC = $_POST['twoC'];
$threeC = $_POST['threeC'];
$fourC = $_POST['fourC'];
$fiveC = $_POST['fiveC'];
$sixC = $_POST['sixC'];
$sevenC = $_POST['sevenC'];
$eightC = $_POST['eightC'];
$nineC = $_POST['nineC'];
$tenC = $_POST['tenC'];
$id = $_POST['id'];

$conn = mysql_connect("localhost", "root", "root");
	if(! $conn)
	{
		echo "Connect Fail!";
		exit;
	}
	mysql_select_db("test");

$qry = "insert into longterm(c_id, one, two, three, four, five, six, seven, eight, nine,  ten) values('$id', '$oneC', '$twoC', '$threeC', '$fourC', '$fiveC', '$sixC', '$sevenC',  '$eightC', '$nineC', '$tenC')";
$result = mysql_query($qry);


if(! $return)
   {
      echo "안들어감...;;;....실패....";
      echo mysql_error();
   }
   else
   {
      echo "들어감";
      echo $id;
   }
 
  mysql_close();
?>