<?php
require_once($_SERVER['DOCUMENT_ROOT'].'/changsun/config.php');
$mysqli=new mysqli($DB['HOST'], $DB['id'], $DB['pw'], $DB['db']);
?>